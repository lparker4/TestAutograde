#!/usr/bin/env python3
# ------------------------------ CODE CELL SETUP -------------------------------
# this code snipped is injected by autograde
__IMPORT_FILTER__ = globals().get('IMPORT_FILTER', None)
__PLOTS__ = []
__LABEL__ = None

if __IMPORT_FILTER__ is not None:
    regex, blacklist = __IMPORT_FILTER__
    print(f'set import filter: regex=r"{regex}", blacklist={blacklist}')

try:
    # If matplotlib is available in the test environment, it is set to headless mode
    # and all plots are dumped to disk instead of being displayed.
    import matplotlib as _mpl
    _mpl.use('Agg')

    from functools import wraps
    from pathlib import Path

    import matplotlib.pyplot as _plt

    from autograde.util import snake_case

    __show = _plt.show
    __save = _plt.savefig

    @wraps(__save)
    def _save(*args, **kwargs):
        __save(*args, **kwargs)
        _plt.close()

    @wraps(__show)
    def _show(*_, **__):
        if _plt.gcf().get_axes():
            root = Path('figures')
            root.mkdir(exist_ok=True)
            path = root / snake_case(f'fig_cell_{__LABEL__}_{len(__PLOTS__) + 1}')
            __PLOTS__.append(path)

            print(f'save figure at {path}')
            _save(path)

    _plt.savefig = _save
    _plt.show = _show

except ImportError:
    print('matplotlib is not available')


auto_save_figure = globals().get('_show', lambda *args, **kwargs: None)

# EXECUTED IN 0.813s
# STDOUT
#     set import filter: regex=r"re.compile('autograde')", blacklist=True

# -------------------------------- CODE CELL 1 ---------------------------------
#
# Example of a recursive function
#

def replaceIs(s):
  """ input: a string s
      output: a new string like s, with
              all lowercase i's with capital I's
  """
  pass

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 1 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 2 ---------------------------------
#
# The vowel-counting example from class...
#

#
# vwl examples from class
#
def vwl(s):
    """vwl returns the number of vowels in s
       Argument: s, which will be a string
    """
    if s == '':
        return 0   # no vowels in the empty string
    elif s[0] in 'aeiou':
        return 1 + vwl(s[1:])   # count 1 for the vowel
    else:
        return 0 + vwl(s[1:])   # The 0 + isn't necessary but looks nice

#
# Tests!
print( "vwl('sequoia') should be 5 <-> ", vwl('sequoia') )
print( "vwl('bcdfg') should be 0 <-> ", vwl('bcdfg') )
print( "vwl('e') should be 1 <-> ", vwl('e') )
print( "vwl('This sentence has nine vowels.') should be 9 <-> ", vwl('This sentence has nine vowels.') )

#
# here are keepvwl and dropvwl, also from class:


#
# keepvwl example from class
#
def keepvwl(s):
    """keepvwl returns the vowels in s
       Argument: s, which will be a string
       Return value: a string with all of s's vowels, in order
    """
    if s == '':
        return ''   # return the empty string
    elif s[0] in 'aeiou':
        return s[0] + keepvwl(s[1:]) # keep s[0], since it's a vowel
    else:
        return '' + keepvwl(s[1:])   # '' isn't necessary but fits conceptually!


#
# dropvwl example from class
#
def dropvwl(s):
    """dropvwl returns the non-vowels in s.  Note that "non-vowels" includes
         characters that are not alphabetic.
       Argument: s, which will be a string
       Return value: s with the vowels removed
    """
    if s == '':
        return ''   # return the empty string
    elif s[0] in 'aeiou':
        return '' + dropvwl(s[1:])   # drop s[0], since it's a vowel
    else:
        return s[0] + dropvwl(s[1:])   # keep s[0], since it's NOT a vowel!




#
# flipside example from Lab 1)
#
def flipside(s):
  """flipside swaps s's sides
     Argument s: a string
  """
  x = len(s)//2
  return s[x:] + s[:x]

#
# Tests for flipside
#
print( "flipside('carpets')  should be  petscar :",  flipside('carpets') )
print( "flipside('homework') should be  workhome :",  flipside('homework') )
print( "flipside('flipside') should be  sideflip :",  flipside('flipside') )
print( "flipside('az')       should be  za :",  flipside('az') )
print( "flipside('a')        should be  a :",  flipside('a') )
print( "flipside('')         should be    :",  flipside('') )
print()
print( "Note that the final test should have two _empty_ strings!")
print( "   Ideally, you won't see them!")

# EXECUTED IN 0.0s
# STDOUT
#     vwl('sequoia') should be 5 <->  5
#     vwl('bcdfg') should be 0 <->  0
#     vwl('e') should be 1 <->  1
#     vwl('This sentence has nine vowels.') should be 9 <->  9
#     flipside('carpets')  should be  petscar : petscar
#     flipside('homework') should be  workhome : workhome
#     flipside('flipside') should be  sideflip : sideflip
#     flipside('az')       should be  za : za
#     flipside('a')        should be  a : a
#     flipside('')         should be    : 
#     
#     Note that the final test should have two _empty_ strings!
#        Ideally, you won't see them!

# ----------------------------- CODE CELL 2 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 3 ---------------------------------
# fun - functions continue to exist in other cells
# try it:

replaceIs('aliiien')   # a three-i'ed alien!

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 3 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 4 ---------------------------------
#
# put your mult(m,n) function here
#
def mult(m,n):
  return 0
  #base case if either is 0
  if m == 0 or n == 0:
    return 0
  #if both are positive, just sum m n times (call itself n times)
  elif m > 0 and n > 0:
    return m + mult(m, n -1)
  #if m is positive but n is negative, treat n as a positive number but negate the final number
  elif m > 0 or n < 0:
    return -mult(m, -n)
  #if m is negative but n is positive, treat m as positive but negate the final number
  elif m < 0 and n > 0:
    return -mult(-m, n)
  #if m and n are negative, treat both as positive
  elif m < 0 and n < 0:
    return mult(-m, -n)


#
# Tests for mult
#

print( "mult(6, 7)           should be  42 :",  mult(6, 7) )
print( "mult(6, -7)          should be  -42 :",  mult(6, -7) )
print( "mult(-6, 7)          should be  -42 :",  mult(-6, 7) )
print( "mult(-6, -7)         should be  42 :",  mult(-6, -7) )
print( "mult(6, 0)           should be  0 :",  mult(6, 0) )
print( "mult(0, 7)           should be  0 :",  mult(0, 7) )
print( "mult(0, 0)           should be  0 :",  mult(0, 0) )

# EXECUTED IN 0.0s
# STDOUT
#     mult(6, 7)           should be  42 : 0
#     mult(6, -7)          should be  -42 : 0
#     mult(-6, 7)          should be  -42 : 0
#     mult(-6, -7)         should be  42 : 0
#     mult(6, 0)           should be  0 : 0
#     mult(0, 7)           should be  0 : 0
#     mult(0, 0)           should be  0 : 0

# ----------------------------- CODE CELL 4 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 5 ---------------------------------
#
# dot(L,K) function here!
#
def dot(L,K):
  #product of the first numbers, add the call again minus first numbers
  if len(L) == len(K) and len(L) > 0 and len(K) > 0:
    return L[0]*K[0] + dot(L[1:], K[1:])
  #base case when the lists are empty or of uneven length
  else:
    return 0.0



#
# Tests for dot function
#
print( "dot([5, 3], [6, 4])  should be  42.0 :",  dot([5, 3], [6, 4]) )
print( "dot([5, 3], [6])     should be  0.0 :",  dot([5, 3], [6]) )
print( "dot([], [6])         should be  0.0 :",  dot([], [6]) )
print( "dot([], [])          should be  0.0 :",  dot([], []) )
print( "dot([1, 2, 3, 4], [10, 100, 1000, 10000]) should be  43210.0 :",  dot([1, 2, 3, 4], [10, 100, 1000, 10000]))

# EXECUTED IN 0.016s
# STDOUT
#     dot([5, 3], [6, 4])  should be  42.0 : 42.0
#     dot([5, 3], [6])     should be  0.0 : 0.0
#     dot([], [6])         should be  0.0 : 0.0
#     dot([], [])          should be  0.0 : 0.0
#     dot([1, 2, 3, 4], [10, 100, 1000, 10000]) should be  43210.0 : 43210.0

# ----------------------------- CODE CELL 5 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 6 ---------------------------------
#
# write your ind(e,L) function here
#
def ind(e, L):
  #base case when code reaches e in L or if e is never found or if e is at first index
  if L[0] == e or len(L) == 0 or e not in L:
    return 0
  #otherwise count 1 and continue to call with list minus first index
  else:
    return 1 + ind(e, L[1:])


#
# Tests for ind
#
print( "ind(42, [55, 77, 42, 12, 42, 100]) should be  2 :",  ind(42, [55, 77, 42, 12, 42, 100]) )
print( "ind(55, [55, 77, 42, 12, 42, 100]) should be  0 :",  ind(55, [55, 77, 42, 12, 42, 100]) )
print( "ind(42, list(range(0, 100)))        should be  5 :",  ind(' ', 'outer exploration') )

# EXECUTED IN 0.0s
# STDOUT
#     ind(42, [55, 77, 42, 12, 42, 100]) should be  2 : 2
#     ind(55, [55, 77, 42, 12, 42, 100]) should be  0 : 0
#     ind(42, list(range(0, 100)))        should be  5 : 5

# ----------------------------- CODE CELL 6 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 7 ---------------------------------
#
# here, write your letterScore function
#
def letterScore (str):
  onepoint = ['a', 'e', 'i', 'o', 'u', 'l', 'n', 's', 't', 'r']
  twopoints = ['d', 'g']
  threepoints = ['b', 'c', 'm', 'p']
  fourpoints = ['f', 'h', 'v', 'w', 'y']
  fivepoints = ['k']
  eightpoints = ['j', 'x']
  tenpoints = ['q', 'z']
  if str in onepoint:
    return 1
  elif str in twopoints:
    return 2
  elif str in threepoints:
    return 3
  elif str in fourpoints:
    return 4
  elif str in fivepoints:
    return 5
  elif str in eightpoints:
    return 8
  elif str in tenpoints:
    return 10
  else:
    return 0
# be sure to try these tests!

print( "letterScore('h') should be  4 :",  letterScore('h') )
print( "letterScore('c') should be  3 :",  letterScore('c') )
print( "letterScore('a') should be  1 :",  letterScore('a') )
print( "letterScore('z') should be 10 :",  letterScore('z') )
print( "letterScore('^') should be  0 :",  letterScore('^') )

# EXECUTED IN 0.0s
# STDOUT
#     letterScore('h') should be  4 : 4
#     letterScore('c') should be  3 : 3
#     letterScore('a') should be  1 : 1
#     letterScore('z') should be 10 : 10
#     letterScore('^') should be  0 : 0

# ----------------------------- CODE CELL 7 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 8 ---------------------------------
#
# here, write your scabbleScore function
#
def scrabbleScore(str):
  #find the letter score of the first index and then repeat with string minus that first index
  if len(str) != 0:
    return letterScore(str[0])+scrabbleScore(str[1:])
  #base case when string is empty
  else:
    return 0






# be sure to try these tests!

#
# Tests
#
print( "scrabbleScore('quetzal')           should be  25 :",  scrabbleScore('quetzal') )
print( "scrabbleScore('jonquil')           should be  23 :",  scrabbleScore('jonquil') )
print( "scrabbleScore('syzygy')            should be  25 :",  scrabbleScore('syzygy') )
print( "scrabbleScore('?!@#$%^&*()')       should be  0 :",  scrabbleScore('?!@#$%^&*()') )
print( "scrabbleScore('')                  should be  0 :",  scrabbleScore('') )
print( "scrabbleScore('abcdefghijklmnopqrstuvwxyz') should be  87 :",  scrabbleScore('abcdefghijklmnopqrstuvwxyz') )

# EXECUTED IN 0.0s
# STDOUT
#     scrabbleScore('quetzal')           should be  25 : 25
#     scrabbleScore('jonquil')           should be  23 : 23
#     scrabbleScore('syzygy')            should be  25 : 25
#     scrabbleScore('?!@#$%^&*()')       should be  0 : 0
#     scrabbleScore('')                  should be  0 : 0
#     scrabbleScore('abcdefghijklmnopqrstuvwxyz') should be  87 : 87

# ----------------------------- CODE CELL 8 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 9 ---------------------------------
#
# A full transcribe function
def transcribe(s):
  #base case
  if len(s) == 0:
    return ""
  #checks if first letter is one to switch, and if so it switches first letter then calls itself again minus first letter
  elif s[0] == "a":
    return "u"+transcribe(s[1:])
  elif s[0] == "c":
    return "g"+transcribe(s[1:])
  elif s[0] == "g":
    return "c"+transcribe(s[1:])
  elif s[0] == "t":
    return "a"+transcribe(s[1:])
  else:
    return s[0]+transcribe(s[1:])



# If you work on this, please create 4-6 tests showing how it does:
print("hello should return hello - " + transcribe("hello"))
print("my name is annie should return my nume is unnie - " + transcribe("my name is annie"))
print("aeiou should return ueiou - " + transcribe("aeiou"))
print("caged should return guced - " + transcribe("caged"))
# tests here...
# model them from the above tests...

# EXECUTED IN 0.0s
# STDOUT
#     hello should return hello - hello
#     my name is annie should return my nume is unnie - my nume is unnie
#     aeiou should return ueiou - ueiou
#     caged should return guced - guced

# ----------------------------- CODE CELL 9 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 10 --------------------------------
#
# here, write your own string-transforming function
#       be sure to use recursion and write at least three tests...

def transform(s):
  """ Arguments: any string
       Results: the string with all 'a's converted into "A for Annie!"s
  """
  if len(s) == 0:
    return ""
  elif s[0] == "a":
    return " A for Annie! " + transform(s[1:])
  else:
    return s[0] + transform(s[1:])

print("'annie' should return 'A for Annie! nnie' - " + transform("annie"))
print("'i ate apples' should return 'i  A for Annie! te  A for Annie! pples' - " + transform("i ate apples"))
print("'aak!' should return ' A for Annie! A for Annie! k' - " + transform("aak"))
# your tests here:

# EXECUTED IN 0.0s
# STDOUT
#     'annie' should return 'A for Annie! nnie' -  A for Annie! nnie
#     'i ate apples' should return 'i  A for Annie! te  A for Annie! pples' - i  A for Annie! te  A for Annie! pples
#     'aak!' should return ' A for Annie! A for Annie! k' -  A for Annie!  A for Annie! k

# ----------------------------- CODE CELL 10 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 11 --------------------------------
import svgutils.compose as sc
from IPython.display import SVG # /!\ note the 'SVG' function also in svgutils.compose
import numpy as np


# here starts the assembling using svgutils 
sc.Figure("8cm", "8cm", 
    sc.Panel(sc.SVG("SVGimage.svg"))
    ).save("compose.svg")
SVG('compose.svg')

# EXECUTED IN 0.016s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmp9c68tjmf", line 8, in <module>
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\svgutils\compose.py", line 115, in __init__
#         svg = _transform.fromfile(fname)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\svgutils\transform.py", line 353, in fromfile
#         with open(fname) as fid:
#     FileNotFoundError: [Errno 2] No such file or directory: '.\\SVGimage.svg'

# ----------------------------- CODE CELL 11 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 12 --------------------------------
#
# Here is space to write pigletLatin and pigLatin!
#
def pigletLatin(s):
  vowels = ["a", "e", "i", "o", "u"]
  if s=="":
    return s
  elif s[0] in vowels:
    return s+"way"
  elif s[0] not in vowels:
    return s[1:]+s[0]+"ay"

print("pigletLatin('be') should return 'ebay' - "+ pigletLatin("be"))
print("pigletLatin('string') should return 'tringsay' - "+ pigletLatin("string"))



def pigLatin(s):
  vowels = ["a", "e", "i", "o", "u"]
  if s=="":
    return ""
  elif s[0] not in vowels:
    if s[0] !="y":
      return pigLatin(s[1:]+s[0])
    else:
      if s[1] in vowels:
        return pigLatin(s[1:]+s[0])
      else:
        return s+"ay"
  elif s[0] in vowels:
    return s + "ay"

# be sure to try these tests!
print( "pigLatin('string')             should be  'ingstray'   :",  pigLatin('string') )
print( "pigLatin('yttrium')            should be  'yttriumway' :",  pigLatin('yttrium') )
print( "pigLatin('yoohoo')             should be  'oohooyay'   :",  pigLatin('yoohoo') )
print( "pigLatin('stymie')             should be  'ymiestay'   :",  pigLatin('stymie') )

# EXECUTED IN 0.0s
# STDOUT
#     pigletLatin('be') should return 'ebay' - ebay
#     pigletLatin('string') should return 'tringsay' - tringsay
#     pigLatin('string')             should be  'ingstray'   : ingstray
#     pigLatin('yttrium')            should be  'yttriumway' : yttriumay
#     pigLatin('yoohoo')             should be  'oohooyay'   : oohooyay
#     pigLatin('stymie')             should be  'ymiestay'   : ymiestay

# ----------------------------- CODE CELL 12 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL TEARDOWN -----------------------------


# EXECUTED IN 0.0s

