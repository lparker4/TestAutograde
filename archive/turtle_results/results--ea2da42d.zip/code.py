#!/usr/bin/env python3
# ------------------------------ CODE CELL SETUP -------------------------------
# this code snipped is injected by autograde
__IMPORT_FILTER__ = globals().get('IMPORT_FILTER', None)
__PLOTS__ = []
__LABEL__ = None

if __IMPORT_FILTER__ is not None:
    regex, blacklist = __IMPORT_FILTER__
    print(f'set import filter: regex=r"{regex}", blacklist={blacklist}')

try:
    # If matplotlib is available in the test environment, it is set to headless mode
    # and all plots are dumped to disk instead of being displayed.
    import matplotlib as _mpl
    _mpl.use('Agg')

    from functools import wraps
    from pathlib import Path

    import matplotlib.pyplot as _plt

    from autograde.util import snake_case

    __show = _plt.show
    __save = _plt.savefig

    @wraps(__save)
    def _save(*args, **kwargs):
        __save(*args, **kwargs)
        _plt.close()

    @wraps(__show)
    def _show(*_, **__):
        if _plt.gcf().get_axes():
            root = Path('figures')
            root.mkdir(exist_ok=True)
            path = root / snake_case(f'fig_cell_{__LABEL__}_{len(__PLOTS__) + 1}')
            __PLOTS__.append(path)

            print(f'save figure at {path}')
            _save(path)

    _plt.savefig = _save
    _plt.show = _show

except ImportError:
    print('matplotlib is not available')


auto_save_figure = globals().get('_show', lambda *args, **kwargs: None)

# EXECUTED IN 0.735s
# STDOUT
#     set import filter: regex=r"re.compile('autograde')", blacklist=True

# -------------------------------- CODE CELL 1 ---------------------------------
#
# This is a code cell - here, you're able to run arbitrary Python scripts.
#

# For example, try running this four-fours example:

from math import *

print("Hello from Colab!")
print()
print("The answer is ", factorial(4)+factorial(4)-4-sqrt(4) )

# EXECUTED IN 0.0s
# STDOUT
#     Hello from Colab!
#     
#     The answer is  42.0

# ----------------------------- CODE CELL 1 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 2 ---------------------------------
get_ipython().system('pip install ColabTurtlePlus')

# EXECUTED IN 2.55s
# STDOUT
#     Requirement already satisfied: ColabTurtlePlus in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (2.0.1)
# STDERR
#     [notice] A new release of pip is available: 23.2.1 -> 23.3.1
#     [notice] To update, run: C:\Users\laure\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\python.exe -m pip install --upgrade pip

# ----------------------------- CODE CELL 2 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 3 ---------------------------------
import ColabTurtlePlus.Turtle as t

# after installing, run this cell...
# if it works, you may see a message -- and you should be set!

# EXECUTED IN 0.016s
# STDOUT
#     Put clearscreen() as the first line in a cell (after the import command) to re-run turtle commands in the cell

# ----------------------------- CODE CELL 3 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 4 ---------------------------------
import ColabTurtlePlus.Turtle as t
import matplotlib.pyplot as plt
t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area
t.bgcolor("AliceBlue") # sets the background color (could also use "#E0E0FF" on the Mac)

t.shape('turtle2') # Options: ['turtle', 'ring', 'classic', 'arrow', 'square', 'triangle', 'circle', 'turtle2', 'blank']

t.speed(5)         # 10 is fastest, 1 is slowest

# side one
t.color("green")   # a link below shares _all_ the colors
t.width(5)         # number of pixels wide for the turtle's trail
t.forward(100)     # forward 100 pixels
t.left(90)         # left 90 degrees

# side two
t.color("DodgerBlue")    # hometeam?!
t.width(2)
t.forward(100)
t.left(90)

# side three
t.penup()          # "lift" the pen - the turtle will not draw
t.forward(100)
t.left(90)
t.pendown()        # put the pen back "down": drawing will resume

# side four
t.color("purple")
t.forward(100)
t.left(135)        # to aim "northeast"
t.penup()
from math import sqrt
t.forward(50*sqrt(2))   # move to the "middle": 50*sqrt(2)
t.color("green")
cv = t.saveSVG(turtle = True)

# EXECUTED IN 0.0s
# STDOUT
#     <IPython.core.display.HTML object>
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmplwu72buw", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 4 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 5 ---------------------------------
# Here is a Colab cell for your "Polygon practice"
#
#      (feel free to copy-paste-adapt, from above)

import ColabTurtlePlus.Turtle as t
from ColabTurtlePlus.Turtle import *

clearscreen()      # it's good to start every cell with this
setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
showborder()       # show the border of the drawing area
bgcolor("AliceBlue") # sets the background color (could also use "#F0F8FF")

t.shape('turtle2') # Options: ['turtle', 'ring', 'classic', 'arrow', 'square', 'triangle', 'circle', 'turtle2', 'blank']

t.speed(5)         # 10 is fastest, 1 is slowest

# side one
t.color("green")   # a link below shares _all_ the colors
t.width(5)         # number of pixels wide for the turtle's trail
t.forward(100)     # forward 100 pixels
t.left(90)         # left 90 degrees

t.color("blue")   # a link below shares _all_ the colors
t.width(5)         # number of pixels wide for the turtle's trail
t.forward(100)     # forward 100 pixels
t.left(90)         # left 90 degrees

t.color("red")   # a link below shares _all_ the colors
t.width(5)         # number of pixels wide for the turtle's trail
t.forward(100)     # forward 100 pixels
t.left(90)         # left 90 degrees

t.color("yellow")   # a link below shares _all_ the colors
t.width(5)         # number of pixels wide for the turtle's trail
t.forward(100)     # forward 100 pixels
t.left(135)         # left 90 degrees

t.color("orange")   # a link below shares _all_ the colors
t.width(5)         # number of pixels wide for the turtle's trail
t.forward(141)     # forward 100 pixels
t.left(90)         # left 90 degrees

# EXECUTED IN 0.016s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmph10hvxnz", line 9, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 5 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 6 ---------------------------------
import ColabTurtlePlus.Turtle as t
import random

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

#
# our tri function
#
def tri(n):
    """Draws n 100-pixel sides of an equilateral triangle.
      Note that n doesn't have to be 3 (!)
    """
    clr = random.choice(('purple', 'pink', 'violet'))
    t.color(clr)
    if n == 0:
        return      # No sides to draw, so stop drawing
    else:
        t.forward(100)
        t.left(120)
        tri(n-1)    # Recur to draw the rest of the sides!

#
# here, run tri(3)
#
t.fillcolor('pink')
t.begin_fill()
tri(3)
t.end_fill()

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpe0ilw6r6", line 5, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 6 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 7 ---------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def spiral(initialLength, angle, multiplier):
    """Spiral-drawing function.  Arguments:
       initialLength = the length of the first leg of the spiral
       angle = the angle, in degrees, turned after each spiral's leg
       multiplier = the fraction by which each leg of the spiral changes
    """
    if initialLength <= 1 or initialLength > 1000:
        return      # No more to draw, this base case stops the recursion
    else:
        t.forward(initialLength)
        t.left(angle)
        spiral(multiplier * initialLength, angle, multiplier )  # What inputs?!

spiral(100, 90, 0.9)   # here, call spiral!

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmptmvxgo7b", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 7 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 8 ---------------------------------
# The chai function

import ColabTurtlePlus.Turtle as t

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def chai(size):
    """Our chai function!"""
    if (size < 5):
        return
    else:
        t.forward(size)
        t.left(90)
        t.forward(size/2)
        t.right(90)

        chai(size/2)

        t.right(90)
        t.forward(size)
        t.left(90)

        chai(size/2)

        t.left(90)
        t.forward(size/2)
        t.right(90)
        t.backward(size)
        return

#
# This runs the chai function:
#
chai(100)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpl9bo93d7", line 6, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 8 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 9 ---------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def svtree(trunklength, levels):
    """svtree: draws a side-view tree
       trunklength = the length of the first line drawn ("the trunk")
       levels = the depth of recursion to which it continues branching
    """
    if levels == 0:
        return
    else:
        t.forward(trunklength)
        t.left(30)
        svtree(trunklength/2, levels-1)
        t.right(60)
        svtree(trunklength/2, levels-1)
        t.left(30)
        t.backward(trunklength)

#
# setup - move the turtle backward a bit:
#
t.penup()
t.backward(150)
t.pendown()

# Go!  One example:
svtree(50, 4)

# try svtree(100,5)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmptpwvspeb", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 9 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 10 --------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def flakeside(sidelength, levels):
    """ flakeside draws _one side_ of the fractal Koch snowflake
    """
    if levels == 0:
      t.forward(sidelength)
      return
    else:
      flakeside(sidelength/3, levels-1)
      t.right(60)
      flakeside(sidelength/3, levels-1)
      t.left(120)
      flakeside(sidelength/3, levels-1)
      t.right(60)
      flakeside(sidelength/3, levels-1)

def snowflake(sidelength, levels):
    """Fractal snowflake function, complete.
       sidelength: pixels in the largest-scale triangle side
       levels: the number of recursive levels in each side
    """
    flakeside(sidelength, levels)     # needs to be implemented - see below
    t.left(120)
    flakeside(sidelength, levels)
    t.left(120)
    flakeside(sidelength, levels)
    t.left(120)

snowflake(200,2)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmplktz3c5w", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 10 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 11 --------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def flakeside(sidelength, levels):
    """ flakeside draws _one side_ of the fractal Koch snowflake
    """
    if levels == 0:
      t.forward(sidelength)
      return
    else:
      flakeside(sidelength/3, levels-1)
      t.right(60)
      flakeside(sidelength/3, levels-1)
      t.left(120)
      flakeside(sidelength/3, levels-1)
      t.right(60)
      flakeside(sidelength/3, levels-1)

#
# try it!
#
t.penup()
t.goto(-200,0)  # move the pen to a "southwest" corner...
t.pendown()

flakeside(300,2)  # try it...

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpe_8n6cxo", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 11 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 12 --------------------------------
#
# Drawing the Koch snowflake
#

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)



# You'll need both the snowflake function (provided) and flakeside, which you will have written:
def flakeside(sidelength, levels):
    """ flakeside draws _one side_ of the fractal Koch snowflake
    """
    if levels == 0:
      t.forward(sidelength)
      return
    else:
      flakeside(sidelength/3, levels-1)
      t.right(60)
      flakeside(sidelength/3, levels-1)
      t.left(120)
      flakeside(sidelength/3, levels-1)
      t.right(60)
      flakeside(sidelength/3, levels-1)

def snowflake(sidelength, levels):
    """Fractal snowflake function, complete.
       sidelength: pixels in the largest-scale triangle side
       levels: the number of recursive levels in each side
    """
    flakeside(sidelength, levels)     # needs to be implemented - see below
    t.left(120)
    flakeside(sidelength, levels)
    t.left(120)
    flakeside(sidelength, levels)
    t.left(120)
t.penup()
t.goto(-200,-100)  # move the pen to a "southwest" corner...
t.pendown()

snowflake(300,2)   # two recursive levels deep!

#
# Try three - or four - levels, as well.

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmp4lua3j4q", line 6, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 12 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 13 --------------------------------
# run this cell to create a good-job-for-finishing star 🤩

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def star(n):
    """ draws a star!
        call with star(5)
    """
    if n == 0:
        return
    else:
        t.forward(100)
        t.right(144)
        star(n-1)

t.fillcolor("gold")
t.begin_fill()
star(5)
t.end_fill()

t.penup()
t.backward(100)
t.pendown()

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpon2fmizt", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 13 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL TEARDOWN -----------------------------


# EXECUTED IN 0.0s

