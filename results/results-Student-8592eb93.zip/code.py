#!/usr/bin/env python3
# ------------------------------ CODE CELL SETUP -------------------------------
# this code snipped is injected by autograde
__IMPORT_FILTER__ = globals().get('IMPORT_FILTER', None)
__PLOTS__ = []
__LABEL__ = None

if __IMPORT_FILTER__ is not None:
    regex, blacklist = __IMPORT_FILTER__
    print(f'set import filter: regex=r"{regex}", blacklist={blacklist}')

try:
    # If matplotlib is available in the test environment, it is set to headless mode
    # and all plots are dumped to disk instead of being displayed.
    import matplotlib as _mpl
    _mpl.use('Agg')

    from functools import wraps
    from pathlib import Path

    import matplotlib.pyplot as _plt

    from autograde.util import snake_case

    __show = _plt.show
    __save = _plt.savefig

    @wraps(__save)
    def _save(*args, **kwargs):
        __save(*args, **kwargs)
        _plt.close()

    @wraps(__show)
    def _show(*_, **__):
        if _plt.gcf().get_axes():
            root = Path('figures')
            root.mkdir(exist_ok=True)
            path = root / snake_case(f'fig_cell_{__LABEL__}_{len(__PLOTS__) + 1}')
            __PLOTS__.append(path)

            print(f'save figure at {path}')
            _save(path)

    _plt.savefig = _save
    _plt.show = _show

except ImportError:
    print('matplotlib is not available')


auto_save_figure = globals().get('_show', lambda *args, **kwargs: None)

# EXECUTED IN 0.422s
# STDOUT
#     set import filter: regex=r"re.compile('autograde')", blacklist=True

# -------------------------------- CODE CELL 1 ---------------------------------
team_members = [
    {
        'first_name': 'Sample',
        'last_name': 'Student',
        'student_id': 12345
    },
]

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 1 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 2 ---------------------------------
# Imports:
import time
import sys

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 2 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 3 ---------------------------------
# Your solution here:
def turnToDictionary(first, second):
    dictionary = {}
    for i in range(len(first)):
        dictionary[first[i]] = second[i]
    return dictionary

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 3 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 4 ---------------------------------
# Your solution here:
def tenLeapYears():
    years = [2024]
    for i in range (9):
        years.append(years[i] + 4)
    return years

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 4 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 5 ---------------------------------
# Your solution here:
def toPigLatin(original):
    words = str(original).split(sep=" ")
    newString = ""
    print(words)
    for i in range (len(words)):
        tempWord = words[i][1:len(words)] + words[i][0] + "ay"
        newString += tempWord.lower()
        if i < len(words) - 1:
            newString += " "
    return newString

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 5 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 6 ---------------------------------
def problematic():
    raise AssertionError('This function does not work properly.')

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 6 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL TEARDOWN -----------------------------


# EXECUTED IN 0.0s

