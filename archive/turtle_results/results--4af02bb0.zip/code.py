#!/usr/bin/env python3
# ------------------------------ CODE CELL SETUP -------------------------------
# this code snipped is injected by autograde
__IMPORT_FILTER__ = globals().get('IMPORT_FILTER', None)
__PLOTS__ = []
__LABEL__ = None

if __IMPORT_FILTER__ is not None:
    regex, blacklist = __IMPORT_FILTER__
    print(f'set import filter: regex=r"{regex}", blacklist={blacklist}')

try:
    # If matplotlib is available in the test environment, it is set to headless mode
    # and all plots are dumped to disk instead of being displayed.
    import matplotlib as _mpl
    _mpl.use('Agg')

    from functools import wraps
    from pathlib import Path

    import matplotlib.pyplot as _plt

    from autograde.util import snake_case

    __show = _plt.show
    __save = _plt.savefig

    @wraps(__save)
    def _save(*args, **kwargs):
        __save(*args, **kwargs)
        _plt.close()

    @wraps(__show)
    def _show(*_, **__):
        if _plt.gcf().get_axes():
            root = Path('figures')
            root.mkdir(exist_ok=True)
            path = root / snake_case(f'fig_cell_{__LABEL__}_{len(__PLOTS__) + 1}')
            __PLOTS__.append(path)

            print(f'save figure at {path}')
            _save(path)

    _plt.savefig = _save
    _plt.show = _show

except ImportError:
    print('matplotlib is not available')


auto_save_figure = globals().get('_show', lambda *args, **kwargs: None)

# EXECUTED IN 0.922s
# STDOUT
#     set import filter: regex=r"re.compile('autograde')", blacklist=True

# -------------------------------- CODE CELL 1 ---------------------------------
import ColabTurtlePlus.Turtle as t
import random  # Import the random module for color randomness
from PIL import Image # NEW IMPORT ADDED

# EXECUTED IN 0.015s
# STDOUT
#     Put clearscreen() as the first line in a cell (after the import command) to re-run turtle commands in the cell

# ----------------------------- CODE CELL 1 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.016s

# -------------------------------- CODE CELL 2 ---------------------------------


# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 2 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 3 ---------------------------------
t.clearscreen()
t.setup(500, 500)
t.showborder()
t.bgcolor("AliceBlue")
t.shape('turtle2')
t.speed(10)  # Adjust the speed as needed

def tri(n):
    """Draws n 100-pixel sides of an equilateral triangle.
    Note that n doesn't have to be 3 (!)
    """
    if n == 0:
        return  # No sides to draw, so stop drawing
    else:
        t.forward(100)
        t.left(120)
        tri(n-1)  # Recur to draw the rest of the sides!

# Filling the triangle with a color
t.fillcolor('lightblue')  # Change the fill color as needed
t.begin_fill()
tri(3)
t.end_fill()
# Changing line thickness and color randomly
t.width(5)  # Adjust line thickness as needed
clr = random.choice(['darkgreen', 'red', 'blue'])  # Random color selection
t.color(clr)

# Drawing a filled circle (dot)
t.dot(10, 'yellow')  # Adjust dot size and color as needed

t.penup()
cv = t.saveSVG(turtle = True)

# EXECUTED IN 0.0s
# STDOUT
#     <IPython.core.display.HTML object>
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpjc6umvse", line 2, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 3 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 4 ---------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()
t.setup(500, 500)
t.showborder()
t.bgcolor("AliceBlue")
t.shape("turtle2")
t.speed(10)
t.width(2)

def flakeside(sidelength, levels):
    """flakeside draws one side of the fractal Koch snowflake."""
    if levels == 0:
        t.forward(sidelength)
    else:
        sidelength /= 3.0
        flakeside(sidelength, levels - 1)
        t.left(60)
        flakeside(sidelength, levels - 1)
        t.right(120)
        flakeside(sidelength, levels - 1)
        t.left(60)
        flakeside(sidelength, levels - 1)

# Try it!
t.penup()
t.goto(-200, 0)  # move the pen to a "southwest" corner...
t.pendown()
flakeside(300, 3)  # Try different levels here

# EXECUTED IN 0.016s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpsioiuohk", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 4 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 5 ---------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()
t.setup(500, 500)
t.showborder()
t.bgcolor("AliceBlue")
t.shape("turtle2")
t.speed(10)
t.width(2)

def spiral(initialLength, angle, multiplier):
    """Spiral-drawing function. Arguments:
       initialLength = the length of the first leg of the spiral
       angle = the angle, in degrees, turned after each spiral's leg
       multiplier = the fraction by which each leg of the spiral changes
    """
    if initialLength <= 1 or initialLength > 1000:
        return  # No more to draw, this base case stops the recursion
    else:
        t.forward(initialLength)  # Draw the current leg
        t.left(angle)            # Turn left by the specified angle
        # Recursively call spiral with updated parameters
        spiral(initialLength * multiplier, angle, multiplier)

spiral(100, 90, 0.9)   # Call spiral with initial values

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmps4nbxkxf", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 5 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 6 ---------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()
t.setup(500, 500)
t.showborder()
t.bgcolor("AliceBlue")
t.shape("turtle2")
t.speed(10)
t.width(2)

def chai(size):
    """Our chai function!"""
    if size < 5:
        return
    else:
        t.forward(size)
        t.left(90)
        t.forward(size / 2)
        t.right(90)

        # First recursive branch
        chai(size / 2)

        t.right(90)
        t.forward(size)
        t.left(90)

        # Second recursive branch
        chai(size / 2)

        t.left(90)
        t.forward(size / 2)
        t.right(90)
        t.backward(size)
        return

# This runs the chai function:
chai(100)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpu700r1h4", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 6 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 7 ---------------------------------
import ColabTurtlePlus.Turtle as t

t.clearscreen()
t.setup(500, 500)
t.showborder()
t.bgcolor("AliceBlue")
t.shape("turtle2")
t.speed(10)
t.width(2)

def svtree(trunklength, levels, branches=2, angle=45):
    """svtree: draws a side-view tree with customizable branches and angles
       trunklength = the length of the first line drawn ("the trunk")
       levels = the depth of recursion to which it continues branching
       branches = the number of branches (default is 2)
       angle = the angle between branches (default is 45 degrees)
    """
    if levels == 0:
        return
    else:
        # Draw the original trunk (1 line)
        t.forward(trunklength)

        # Recursive branches
        for _ in range(branches):
            t.left(angle)
            svtree(trunklength / 2, levels - 1, branches, angle)
            t.right(angle)

        # Go back to the trunk's position and orientation
        t.backward(trunklength)

# Go! Example with 3 branches and a 30-degree angle:
svtree(100, 4, branches=3, angle=30)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmptru_2lcp", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 7 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 8 ---------------------------------
# run this cell to create a good-job-for-finishing star 🤩

t.clearscreen()      # it's good to start every cell with this
t.setup(500,500)     # setup the drawing area to be 500 pixels x 500 pixels
t.showborder()       # show the border of the drawing area

t.bgcolor("AliceBlue")   # adjust to your preferences!
t.shape("turtle2")
t.speed(10)
t.width(2)

def star(n):
    """ draws a star!
        call with star(5)
    """
    if n == 0:
        return
    else:
        t.forward(100)
        t.right(144)
        star(n-1)

t.fillcolor("gold")
t.begin_fill()
star(5)
t.end_fill()

t.penup()
t.backward(100)
t.pendown()

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmp0j2wpeo4", line 4, in <module>
#       File "<string>", line 4, in setup
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 565, in setup
#         self._updateDrawing(delay=False)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\ColabTurtlePlus\Turtle.py", line 329, in _updateDrawing
#         self.drawing_window.update(HTML(self._generateSvgDrawing()))
#     AttributeError: 'NoneType' object has no attribute 'update'

# ----------------------------- CODE CELL 8 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL TEARDOWN -----------------------------


# EXECUTED IN 0.0s

