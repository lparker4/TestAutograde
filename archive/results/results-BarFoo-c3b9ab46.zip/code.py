#!/usr/bin/env python3
# ------------------------------ CODE CELL SETUP -------------------------------
# this code snipped is injected by autograde
__IMPORT_FILTER__ = globals().get('IMPORT_FILTER', None)
__PLOTS__ = []
__LABEL__ = None

if __IMPORT_FILTER__ is not None:
    regex, blacklist = __IMPORT_FILTER__
    print(f'set import filter: regex=r"{regex}", blacklist={blacklist}')

try:
    # If matplotlib is available in the test environment, it is set to headless mode
    # and all plots are dumped to disk instead of being displayed.
    import matplotlib as _mpl
    _mpl.use('Agg')

    from functools import wraps
    from pathlib import Path

    import matplotlib.pyplot as _plt

    from autograde.util import snake_case

    __show = _plt.show
    __save = _plt.savefig

    @wraps(__save)
    def _save(*args, **kwargs):
        __save(*args, **kwargs)
        _plt.close()

    @wraps(__show)
    def _show(*_, **__):
        if _plt.gcf().get_axes():
            root = Path('figures')
            root.mkdir(exist_ok=True)
            path = root / snake_case(f'fig_cell_{__LABEL__}_{len(__PLOTS__) + 1}')
            __PLOTS__.append(path)

            print(f'save figure at {path}')
            _save(path)

    _plt.savefig = _save
    _plt.show = _show

except ImportError:
    print('matplotlib is not available')


auto_save_figure = globals().get('_show', lambda *args, **kwargs: None)

# EXECUTED IN 0.531s
# STDOUT
#     set import filter: regex=r"re.compile('autograde')", blacklist=True

# -------------------------------- CODE CELL 1 ---------------------------------
team_members = [
    {
        'first_name': 'Alice',
        'last_name': 'Foo',
        'student_id': 12345
    },
    {
        'first_name': 'Bob',
        'last_name': 'Bar',
        'student_id': 54321
    }
]

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 1 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 2 ---------------------------------
import sys
import time

import matplotlib.pyplot as plt
import pandas as pd

# EXECUTED IN 0.344s

# ----------------------------- CODE CELL 2 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 3 ---------------------------------
SOME_CONSTANT = 42

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 3 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 4 ---------------------------------
df = pd.DataFrame([[1, 1], [2, 4], [3, 9], [4, 16], [5, 25]])
df.plot()

# EXECUTED IN 0.359s

# ----------------------------- CODE CELL 4 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.078s
# STDOUT
#     save figure at figures\fig_cell_4_clean_1

# -------------------------------- CODE CELL 5 ---------------------------------
from IPython.display import display

display(df)

# EXECUTED IN 0.063s
# STDOUT
#     0   1
#     0  1   1
#     1  2   4
#     2  3   9
#     3  4  16
#     4  5  25

# ----------------------------- CODE CELL 5 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 6 ---------------------------------
with open('foo.txt', mode='rt') as f:
    data = f.read()

print(data[:len(data) // 2])
print(data[len(data) // 2:], file=sys.stderr)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmp_fnxz4ih", line 1, in <module>
#     FileNotFoundError: [Errno 2] No such file or directory: 'foo.txt'

# ----------------------------- CODE CELL 6 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 7 ---------------------------------
with open('bar.txt', mode='a') as f:
    f.write('>> modification by notebook <<')

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 7 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 8 ---------------------------------
with open('fnord.txt', mode='wt') as f:
    f.write('let\'s leave some artifacts in the system')

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 8 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 9 ---------------------------------
for e in [2, 3]:
    plt.plot(*zip(*((v, v ** e) for v in range(-10, 10))))
    plt.show()

# EXECUTED IN 0.157s
# STDOUT
#     save figure at figures\fig_cell_9_1
#     save figure at figures\fig_cell_9_2

# ----------------------------- CODE CELL 9 CLEAN ------------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 10 --------------------------------
plt.plot(*zip(*((v, v ** 5 + (v - 5) ** 3 - (3 * v) ** 2) for v in range(-20, 20))))
plt.savefig('plot.png')

# EXECUTED IN 0.078s

# ----------------------------- CODE CELL 10 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 11 --------------------------------
def square(x: float) -> float:
    return x ** 2


def cube(x: float) -> float:
    return x ** 3


abs_cube = cube


def fail():
    raise ValueError('no chance, this function crashes so badly')


def sleep(x):
    time.sleep(x)

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 11 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 12 --------------------------------
sleep(.1)

# EXECUTED IN 0.125s

# ----------------------------- CODE CELL 12 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 13 --------------------------------
import autograde

print(autograde.__version__)

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpkgqn8x2w", line 1, in <module>
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\unittest\mock.py", line 1114, in __call__
#         return self._mock_call(*args, **kwargs)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\unittest\mock.py", line 1118, in _mock_call
#         return self._execute_mock_call(*args, **kwargs)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\unittest\mock.py", line 1179, in _execute_mock_call
#         result = effect(*args, **kwargs)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 359, in guard
#         raise ImportError(f'usage of "{target}" is not permitted')
#     ImportError: usage of "autograde" is not permitted

# ----------------------------- CODE CELL 13 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 14 --------------------------------
def illegal_import():
    exec('import autograde as ag')

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL 14 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 15 --------------------------------
assert False, 'this cell will crash under any circumstances ...'

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmp_xmlzsay", line 1, in <module>
#     AssertionError: this cell will crash under any circumstances ...

# ----------------------------- CODE CELL 15 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 16 --------------------------------
print('... but this cell is not affected :^)')

# EXECUTED IN 0.0s
# STDOUT
#     ... but this cell is not affected :^)

# ----------------------------- CODE CELL 16 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 17 --------------------------------
# fails
get_ipython().system('pip install poetry')

# EXECUTED IN 2.0s
# STDOUT
#     Requirement already satisfied: poetry in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (1.5.1)
#     Requirement already satisfied: build<0.11.0,>=0.10.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.10.0)
#     Requirement already satisfied: cachecontrol[filecache]<0.13.0,>=0.12.9 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.12.14)
#     Requirement already satisfied: cleo<3.0.0,>=2.0.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (2.0.1)
#     Requirement already satisfied: crashtest<0.5.0,>=0.4.1 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.4.1)
#     Requirement already satisfied: dulwich<0.22.0,>=0.21.2 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.21.5)
#     Requirement already satisfied: filelock<4.0.0,>=3.8.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (3.12.0)
#     Requirement already satisfied: html5lib<2.0,>=1.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.1)
#     Requirement already satisfied: installer<0.8.0,>=0.7.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.7.0)
#     Requirement already satisfied: jsonschema<5.0.0,>=4.10.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (4.19.1)
#     Requirement already satisfied: keyring<24.0.0,>=23.9.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (23.13.1)
#     Requirement already satisfied: lockfile<0.13.0,>=0.12.2 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.12.2)
#     Requirement already satisfied: packaging>=20.4 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (23.1)
#     Requirement already satisfied: pexpect<5.0.0,>=4.7.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (4.8.0)
#     Requirement already satisfied: pkginfo<2.0.0,>=1.9.4 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.9.6)
#     Requirement already satisfied: platformdirs<4.0.0,>=3.0.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (3.5.1)
#     Requirement already satisfied: poetry-core==1.6.1 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.6.1)
#     Requirement already satisfied: poetry-plugin-export<2.0.0,>=1.4.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.4.0)
#     Requirement already satisfied: pyproject-hooks<2.0.0,>=1.0.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.0.0)
#     Requirement already satisfied: requests<3.0,>=2.18 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (2.31.0)
#     Requirement already satisfied: requests-toolbelt<2,>=0.9.1 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.0.0)
#     Requirement already satisfied: shellingham<2.0,>=1.5 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.5.0.post1)
#     Requirement already satisfied: tomli<3.0.0,>=2.0.1 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (2.0.1)
#     Requirement already satisfied: tomlkit<1.0.0,>=0.11.4 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (0.11.8)
#     Requirement already satisfied: trove-classifiers>=2022.5.19 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (2023.5.24)
#     Requirement already satisfied: urllib3<2.0.0,>=1.26.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (1.26.16)
#     Requirement already satisfied: virtualenv<21.0.0,>=20.22.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from poetry) (20.23.0)
#     Requirement already satisfied: colorama in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from build<0.11.0,>=0.10.0->poetry) (0.4.6)
#     Requirement already satisfied: msgpack>=0.5.2 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from cachecontrol[filecache]<0.13.0,>=0.12.9->poetry) (1.0.5)
#     Requirement already satisfied: rapidfuzz<3.0.0,>=2.2.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from cleo<3.0.0,>=2.0.0->poetry) (2.15.1)
#     Requirement already satisfied: six>=1.9 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from html5lib<2.0,>=1.0->poetry) (1.16.0)
#     Requirement already satisfied: webencodings in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from html5lib<2.0,>=1.0->poetry) (0.5.1)
#     Requirement already satisfied: attrs>=22.2.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from jsonschema<5.0.0,>=4.10.0->poetry) (23.1.0)
#     Requirement already satisfied: jsonschema-specifications>=2023.03.6 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from jsonschema<5.0.0,>=4.10.0->poetry) (2023.7.1)
#     Requirement already satisfied: referencing>=0.28.4 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from jsonschema<5.0.0,>=4.10.0->poetry) (0.30.2)
#     Requirement already satisfied: rpds-py>=0.7.1 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from jsonschema<5.0.0,>=4.10.0->poetry) (0.10.3)
#     Requirement already satisfied: jaraco.classes in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from keyring<24.0.0,>=23.9.0->poetry) (3.2.3)
#     Requirement already satisfied: importlib-metadata>=4.11.4 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from keyring<24.0.0,>=23.9.0->poetry) (6.7.0)
#     Requirement already satisfied: pywin32-ctypes>=0.2.0 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from keyring<24.0.0,>=23.9.0->poetry) (0.2.1)
#     Requirement already satisfied: ptyprocess>=0.5 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from pexpect<5.0.0,>=4.7.0->poetry) (0.7.0)
#     Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from requests<3.0,>=2.18->poetry) (3.2.0)
#     Requirement already satisfied: idna<4,>=2.5 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from requests<3.0,>=2.18->poetry) (2.10)
#     Requirement already satisfied: certifi>=2017.4.17 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from requests<3.0,>=2.18->poetry) (2023.5.7)
#     Requirement already satisfied: distlib<1,>=0.3.6 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from virtualenv<21.0.0,>=20.22.0->poetry) (0.3.6)
#     Requirement already satisfied: zipp>=0.5 in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from importlib-metadata>=4.11.4->keyring<24.0.0,>=23.9.0->poetry) (3.15.0)
#     Requirement already satisfied: more-itertools in c:\users\laure\appdata\local\packages\pythonsoftwarefoundation.python.3.10_qbz5n2kfra8p0\localcache\local-packages\python310\site-packages (from jaraco.classes->keyring<24.0.0,>=23.9.0->poetry) (9.1.0)
# STDERR
#     [notice] A new release of pip is available: 23.2.1 -> 23.3.1
#     [notice] To update, run: C:\Users\laure\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\python.exe -m pip install --upgrade pip

# ----------------------------- CODE CELL 17 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# -------------------------------- CODE CELL 18 --------------------------------
# also fails
get_ipython().run_line_magic('', 'pip install poetry')

# EXECUTED IN 0.0s
# STDERR
#     Traceback (most recent call last):
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\notebook_executor.py", line 176, in exec_notebook
#         shadow_context.enter_context(shadow_exec(code_cell, state, timeout=timeout))
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 492, in enter_context
#         result = _cm_type.__enter__(cm)
#       File "C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.3056.0_x64__qbz5n2kfra8p0\lib\contextlib.py", line 135, in __enter__
#         return next(self.gen)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 296, in shadow_exec
#         exec_function(compile(source, shadow_copy.name, mode='exec'), *args)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in exec_with_timeout
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 266, in run_with_timeout
#         return worker.result()
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 244, in result
#         raise result
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 205, in wrapper
#         self._result_queue.put(target(*args, **kwargs))
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\autograde\util.py", line 276, in <lambda>
#         run_with_timeout(lambda: exec(*args), timeout=timeout)
#       File "C:\Users\laure\AppData\Local\Temp\tmpx69oqja4", line 2, in <module>
#       File "C:\Users\laure\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.10_qbz5n2kfra8p0\LocalCache\local-packages\Python310\site-packages\IPython\core\interactiveshell.py", line 2397, in run_line_magic
#         raise UsageError(etpl % (magic_name, extra))
#     IPython.core.error.UsageError: Line magic function `%` not found.

# ----------------------------- CODE CELL 18 CLEAN -----------------------------
auto_save_figure()

# EXECUTED IN 0.0s

# ----------------------------- CODE CELL TEARDOWN -----------------------------


# EXECUTED IN 0.0s

